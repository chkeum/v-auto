# 플랫폼 인프라 가이드 (Infrastructure Guide)

> **문서 번호**: SOP-VM-02
> **대상 독자**: 기술지원팀 (Technical Support), 인프라 관리자 (Admin)
> **목표**: v-auto가 참조하는 인프라(네트워크, 이미지)의 구조를 이해하고, 필요시 템플릿을 수정한다.

---

## 1. 인프라 디렉토리 구조 (Infrastructure Structure)
 
v-auto는 **"프로젝트별 독립 인프라"**를 지향합니다.
각 프로젝트 폴더 안에 전용 `infrastructure/`가 존재하며, 글로벌 설정은 없습니다.

```text
v-auto/
├── vm_manager.py
└── projects/
    └── [프로젝트명]/
        ├── [서비스명].yaml # VM 스펙 + 인프라 정의 (All-in-One)
        └── infrastructure/  # (선택적) 별도 인프라 파일이 필요할 경우
```

> **참고**: 최신 버전에서는 `[서비스명].yaml` 파일 내부에 `infrastructure:` 블록을 직접 정의하는 것을 권장합니다. (SOP 참조)

---

## 2. 주요 개념 설명 (Concepts)

### 🌐 네트워크 추상화 (Network Abstraction)
사용자가 스펙 파일에 `network: default`라고 적었을 때, 실제 매핑될 물리적 정보를 정의합니다.
시스템은 이 정보를 바탕으로 OpenShift의 `NetworkAttachmentDefinition`, `IPPool` 등을 자동으로 연결합니다.

*   **NAD (NetworkAttachmentDefinition)**: 실제 물리 인터페이스와 연결된 OpenShift 리소스 이름
*   **IPAM (IP Address Management)**: IP 할당 방식 (`whereabouts` 등)과 대역 정보

### 💿 이미지 카탈로그 (Image Catalog)
사용 가능한 OS 이미지 목록을 관리합니다.
*   **URL**: `http` 프로토콜을 통해 이미지를 다운로드하거나, PVC를 클론합니다.
*   **Min CPU/Mem**: 해당 OS가 구동되기 위한 최소 사양을 강제하여, 배포 실패를 방지합니다.

---

## 3. 보안 메커니즘 (Security)

### 🔒 관리자 백도어 (Admin Keys)
운영팀이 언제든 VM에 접속하여 장애 처리를 할 수 있도록, 배포 시 **운영팀 전용 SSH Key**가 자동으로 주입됩니다.
*   키 위치: `infrastructure/admin.pub` (파일이 존재할 경우)
*   동작: `cloud-init` 단계에서 `root` 또는 기본 사용자의 `authorized_keys`에 추가됨

### 🛡️ 비밀번호 해싱 (Password Hashing)
`vm_manager.py`는 배포 시 입력받은 비밀번호를 즉시 **SHA-512** 알고리즘으로 암호화합니다.
*   평문 비밀번호는 어디에도 저장되지 않습니다.
*   `/etc/shadow` 파일 호환 포맷으로 변환되어 VM에 적용됩니다.

---

## 4. GitOps 및 오프라인 배포

### 변경사항 커밋 (Git Sync)
작업 완료 후에는 반드시 스크립트를 통해 변경 이력을 남겨야 합니다.

```bash
# 사용법: ./git_sync.sh "커밋 메시지"
./git_sync.sh "Opasnet web server deployment complete"
```
이 스크립트는 폐쇄망 배포를 위한 **오프라인 번들(`tar.gz`)**도 자동으로 생성하여 `releases/` 폴더에 저장합니다.

---

## 5. 자주 묻는 질문 (FAQ)

**Q. 사용자가 배포하다가 "Valid networks resolving error"가 뜬대요.**
A. 사용자가 스펙 파일(`yaml`)에 적은 네트워크 이름(alias)이 `infrastructure` 블록에 정의되지 않았기 때문입니다. 오타를 확인하거나 정의를 추가하십시오.

**Q. VM 생성 시 특정 커널 파라미터를 적용하고 싶어요.**
A. 스펙 파일의 `cloud_init` -> `runcmd` 섹션을 활용하십시오. 부팅 시 실행될 명령어를 자유롭게 기술할 수 있습니다.

---
