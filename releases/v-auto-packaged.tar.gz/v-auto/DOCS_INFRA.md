# v-auto v2.0 인프라 운영 가이드 (Infrastructure Guide)

> **대상 독자**: 플랫폼 엔지니어, 인프라 관리자 (Admin)  
> **목표**: 표준 환경(네트워크, 이미지, 스토리지)을 정의하고 시스템을 유지보수한다.

---

## 1. 인프라 디렉토리 구조 (Decentralized)
 
v1.0 아키텍처는 **"프로젝트별 독립 인프라"**를 지향합니다.
각 프로젝트 폴더 안에 전용 `infrastructure/`가 존재하며, 글로벌 설정은 없습니다.

```text
v-auto/
├── vm_manager.py
└── projects/
    └── [프로젝트명]/
        ├── specs/           # VM 스펙 정의
        ├── config.yaml      # 프로젝트 기본 설정
        └── infrastructure/  # 👈 인프라(네트워크/이미지) 정의
            ├── networks.yaml
            ├── images.yaml
            └── storage.yaml
```

### 📄 `networks.yaml` 작성법
사용자가 `network: svc-net`이라고 적었을 때, 실제 매핑될 물리적 정보를 정의합니다.

```yaml
networks:
  svc-net:
    # 1. OpenShift NAD (NetworkAttachmentDefinition) 위치
    nad: default/svc-net-nad
    
    # 2. IPAM 및 게이트웨이 정보 (자동 주입용)
    subnet: 10.215.100.0/24
    gateway: 10.215.100.1
    dns: [8.8.8.8, 1.1.1.1]
```

### 📄 `images.yaml` 작성법
사용자가 사용할 수 있는 OS 이미지 목록을 통제합니다.

```yaml
images:
  ubuntu-22.04:
    url: "http://repo.internal/images/ubuntu-22.04.qcow2"
    min_cpu: 2  # 최소 요구 사양 강제
    min_mem: 2Gi
```

---

## 2. 보안 및 자동화 메커니즘

### 🔒 관리자 백도어 (Admin Keys)
사용자가 어떤 설정을 하든, 운영팀이 언제든 VM에 접속할 수 있어야 합니다.
*   `vm_manager.py`는 배포 시 **`infrastructure/admin.pub` (존재할 경우)** 키를 모든 VM에 자동으로 심습니다.
*   비상시 운영팀의 Private Key로 접속하여 복구할 수 있습니다.

### 🛡️ 비밀번호 해싱 (Password Hashing)
`vm_manager.py`는 Python `crypt` 모듈(SHA-512)을 내장하고 있습니다.
*   사용자가 입력한 비밀번호는 즉시 해싱되어 `cloud-init`에 기록됩니다.
*   `/etc/shadow` 파일에 안전하게 저장되므로, `cloud-init` 로그를 탈취당해도 비밀번호 원문을 알 수 없습니다.

---

## 3. Gitops 및 배포 관리

### 변경사항 커밋 (Git Sync)
인프라 설정이나 코드를 변경한 후에는 반드시 스크립트를 통해 커밋하십시오.

```bash
# 사용법: ./git_sync.sh "커밋 메시지"
./git_sync.sh "Update network gateway"
```
이 스크립트는 폐쇄망 배포를 위한 **오프라인 번들(`tar.gz`)**도 자동으로 생성합니다.

---

## 4. 문제 해결 (Troubleshooting)

**Q. 사용자가 배포하다가 "Valid networks resolving error"가 뜬대요.**
A. 사용자가 `specs/*.yaml`에 적은 네트워크 이름이 `infrastructure/networks.yaml`에 정의되어 있는지 확인하세요. 오타일 확률 99%입니다.

**Q. 템플릿을 수정하고 싶어요.**
A. `infrastructure/templates/` 폴더 안의 `vm_template.yaml` 등을 수정하세요. Jinja2 문법을 따릅니다.
